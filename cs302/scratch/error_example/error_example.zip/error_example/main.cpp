#include "Example.h"

int main() {
    Example<int> e;

    return 0;
}