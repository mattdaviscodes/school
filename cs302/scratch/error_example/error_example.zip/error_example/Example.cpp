//
// Created by Matthew Davis on 9/17/18.
//

#include "Example.h"


template<class ItemType>
Example<ItemType>::Example() : data(5) {}