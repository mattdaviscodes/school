//
// Created by Matthew Davis on 9/17/18.
//

#ifndef SCHOOL_EXAMPLE_H
#define SCHOOL_EXAMPLE_H

template<class ItemType>
class Example {
private:
    int data;
public:
    Example();
};


#endif //SCHOOL_EXAMPLE_H
